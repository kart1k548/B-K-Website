const express = require('express');

const path = require('path');

const app = express();

const mongoose = require("mongoose");

app.use(express.static(__dirname + '/public'));
app.set("view engine", "ejs");
app.set("views", "views");

const homeRoutes = require('./routes/home');
const aboutRoutes = require('./routes/about');
const productRoutes = require('./routes/product');
const contactRoutes = require('./routes/contact');
const loginRoutes = require('./routes/login');
const signupRoutes = require('./routes/signup');
app.use(express.static(path.join(__dirname,'public')));

app.use('/about',aboutRoutes);
app.use('/product',productRoutes);
app.use('/contact',contactRoutes);
app.use('/login',loginRoutes);
app.use('/signup',signupRoutes);
app.use(homeRoutes);

mongoose.connect("mongodb+srv://BK_User:BK_User@bk-cluster.rp2i3.mongodb.net/<dbname>?retryWrites=true&w=majority")
.then(()=>{
    console.log("Database Connected");
})

app.listen(5001,()=>{
    console.log('Listening to 5001');
});
