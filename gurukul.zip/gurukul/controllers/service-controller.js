exports.servicePage = (req,res,next) =>{
    res.render('viewer/service',{
        pageTitle: " Service"
    });
   
}