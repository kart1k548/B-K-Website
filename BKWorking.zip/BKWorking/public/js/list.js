$(document).ready(function(){



    $('.items').slick({
    infinite: true,
    lazyLoad: 'ondemand',
    slidesToShow: 3,
    slidesToScroll: 3
    });
    
    
    
    
    
    
    });