exports.checkoutPage = (req,res,next) =>{
    res.render('viewer/checkout',{
        pageTitle: "B&K checkout"
    });
}