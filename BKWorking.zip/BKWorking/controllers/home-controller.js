exports.homePage = (req,res,next) =>{
    res.render('viewer/Home',{
        pageTitle: "B&K Home",
        isAuthenticated: req.session.isLoggedIn
    });
}