exports.listPage = (req,res,next) =>{
    res.render('viewer/list',{
        pageTitle: "B&K List"
    });
}