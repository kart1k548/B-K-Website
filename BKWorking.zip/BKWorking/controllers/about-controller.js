exports.aboutPage = (req,res,next) =>{
    res.render('viewer/about',{
        pageTitle: "B&K About",
        isAuthenticated: req.session.isLoggedIn
    });
}