exports.contactPage = (req,res,next) =>{
    res.render('viewer/Contact',{
        pageTitle: "B&K Contact"
    });
}