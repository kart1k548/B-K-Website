const nodemailer = require("nodemailer");
const sendgridTransport = require("nodemailer-sendgrid-transport");

const Order = require("../models/order");

const transporter = nodemailer.createTransport(
  sendgridTransport({
    auth: {
      api_key:
        process.env.MAIL_KEY
    }
  })
);

exports.productPage = (req, res, next) => {
  res.render("viewer/products", {
    pageTitle: "B&K Products",
    isAuthenticated: req.session.isLoggedIn,
  });
};

exports.checkoutPage = (req, res, next) => {
  res.render("viewer/checkout", {
    pageTitle: "B&K Checkout",
    isAuthenticated: req.session.isLoggedIn,
  });
};

exports.postCheckout = (req, res, next) => {
  const fname = req.body.fname;
  const lname = req.body.lname;
  const email = req.body.email;
  const address = req.body.address;
  const country = req.body.country;
  const state = req.body.state;
  const zip = req.body.zip;
  const model = req.body.model;
  const pno = req.body.pno;
  const order = new Order({
    fname: fname,
    lname: lname,
    email: email,
    address: address,
    country: country,
    state: state,
    zip: zip,
    model: model,
    pno: pno
  });
      return order
        .save()
        .then((result) => {
          res.redirect("/product");
          return transporter.sendMail({
            to: email,
            from: "bktrademart1llp@gmail.com",
            subject: "Thanks for placing your Order from B&K Trademart",
            html: "<h1>Your Order have been successfully placed!</h1>"
          });
        })
        .catch((err) => {
          console.log(err);
        });
};
