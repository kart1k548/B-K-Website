exports.productPage = (req,res,next) =>{
    res.render('viewer/products',{
        pageTitle: "B&K Products",
        isAuthenticated: req.session.isLoggedIn
    });
}

exports.checkoutPage = (req,res,next) =>{
    res.render('viewer/checkout',{
        pageTitle: "B&K Checkout",
        isAuthenticated: req.session.isLoggedIn
    });
}