exports.cartPage = (req,res,next) =>{
    res.render('viewer/cart',{
        pageTitle: "B&K cart"
    });
}