const path = require('path');

const express = require('express');

const router = express.Router();

const productController = require('../controllers/product-controller');

const isAuth = require('../middleware/is-auth');

router.get('/', productController.productPage);

router.get('/checkout', isAuth, productController.checkoutPage);

module.exports = router;